import { gsap } from "gsap";
import type { StoryState } from "@/components/story/story-state";

// A temporary, inert visual bridge. Real links always live in normal HTML flow.
export function createScreenEntry(root: HTMLElement, story: StoryState) {
  const launcher = document.querySelector<HTMLElement>("[data-project-launcher]");
  let animation: gsap.core.Tween | undefined;
  let overlay: HTMLElement | undefined;
  let frame = 0;
  let entered = false;
  let running = false;
  const phase = { value: 0 };
  const reset = () => {
    animation?.kill(); cancelAnimationFrame(frame); overlay?.remove();
    overlay = undefined; running = false; phase.value = 0;
    story.setEntry(0); story.notify();
  };
  const animate = (reverse = false) => {
    if (!launcher || running || story.activeStage !== 6 || !root.querySelector('[data-scene-state="ready"]')) return false;
    const bounds = story.screenBounds;
    if (!bounds || bounds.width < 1 || bounds.height < 1) return false;
    if (reverse) root.scrollIntoView({ block: "start", behavior: "instant" });
    const target = launcher.getBoundingClientRect();
    const top = parseFloat(getComputedStyle(document.documentElement).scrollPaddingTop) || 96;
    const width = target.width;
    const height = innerHeight - top;
    overlay = document.createElement("div");
    overlay.inert = true; overlay.setAttribute("aria-hidden", "true");
    Object.assign(overlay.style, { position: "fixed", top: "0", left: "0", width: `${width}px`, height: `${height}px`, background: "#fafaf8", overflow: "hidden", zIndex: "9", pointerEvents: "none", transformOrigin: "0 0" });
    const copy = launcher.cloneNode(true) as HTMLElement;
    copy.removeAttribute("id"); copy.querySelectorAll("[id]").forEach(node => node.removeAttribute("id"));
    copy.querySelector("[data-return-story]")?.remove();
    overlay.append(copy); document.body.append(overlay);
    phase.value = reverse ? 1 : 0; running = true;
    const draw = () => {
      story.setEntry(phase.value); story.notify();
      const display = story.screenBounds ?? bounds;
      const blend = gsap.utils.clamp(0, 1, (phase.value - .3) / .7);
      const left = gsap.utils.interpolate(display.left, target.left, blend);
      const y = gsap.utils.interpolate(display.top, top, blend);
      const sx = gsap.utils.interpolate(display.width / width, 1, blend);
      const sy = gsap.utils.interpolate(display.height / height, 1, blend);
      if (overlay) {
        overlay.style.transform = `translate(${left}px, ${y}px) scale(${sx}, ${sy})`;
        overlay.style.opacity = `${gsap.utils.clamp(0, 1, (phase.value - .25) / .35)}`;
        overlay.style.borderRadius = `${(1 - blend) * 16}px`;
      }
    };
    draw();
    animation = gsap.to(phase, { value: reverse ? 0 : 1, duration: 1.4, ease: "power2.inOut", onUpdate: draw, onComplete: () => {
      running = false; entered = !reverse;
      if (!reverse) {
        launcher.scrollIntoView({ block: "start", behavior: "instant" });
        launcher.querySelector<HTMLElement>("h2")?.focus({ preventScroll: true });
      } else root.focus({ preventScroll: true });
      frame = requestAnimationFrame(reset);
    }});
    return true;
  };
  const cancelOnScroll = () => { if (running) reset(); };
  const escape = (event: KeyboardEvent) => { if (event.key === "Escape") reset(); };
  const returnToStory = (event: MouseEvent) => {
    if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey || !entered) return;
    if ((event.target as Element).closest("[data-return-story]") && animate(true)) event.preventDefault();
  };
  window.addEventListener("scroll", cancelOnScroll, { passive: true });
  root.addEventListener("keydown", escape);
  launcher?.addEventListener("click", returnToStory);
  return {
    get running() { return running; },
    finish: () => animation?.progress(1),
    enter: () => animate(), cancel: reset,
    destroy() { reset(); window.removeEventListener("scroll", cancelOnScroll); root.removeEventListener("keydown", escape); launcher?.removeEventListener("click", returnToStory); },
  };
}
